import books from './booklist.js';


let newbooks = document.querySelector('#content')

let ul = "<ul>"
for (let i in books){
ul += "<li>"
ul += "<div>"
    ul+=  `<img src="../images/${books[i].photo}" alt="">`
    ul+= `<p><span>제목:</span> ${books[i].subject}</p>`
    ul+= `<p><span>저자</span>: ${books[i].author}</p>`
    ul+= `<p<span>출판사:</span> ${books[i].publisher}</p>`
    ul+= `<p><span>발행일:</span> ${books[i].date}</p>`
    ul+= `<p><span>가격:</span> ${books[i].price}</p>`
    ul+= `<p><span>요약:</span> ${books[i].summary}</p>`
    ul+=  `<button onclick = remove(this)>삭제</button>`
    ul += "</div>"
ul += "</li>"
}
ul += "</ul>"
newbooks.innerHTML = ul;

function remove(btn){
let findIndex = books.indexOf(btn.parentnod().parentnod())
books.splice(findIndex, 1)
}


console.log(books)